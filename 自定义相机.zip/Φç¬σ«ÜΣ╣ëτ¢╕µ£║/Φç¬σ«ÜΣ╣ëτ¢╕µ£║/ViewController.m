//
//  ViewController.m
//  自定义相机
//
//  Created by 孟令博 on 16/6/30.
//  Copyright © 2016年 孟令博. All rights reserved.
//

#import "ViewController.h"
#import "InterfaceViewController.h"
#import "SecondViewController.h"

@interface ViewController ()<InterfaceVCDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    btn.frame = CGRectMake(0, 0, 80, 40);
    btn.center = self.view.center;
    [btn setTitle:@"拍照" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btnPressed:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
}

- (void)btnPressed:(id)sender {
    InterfaceViewController *nav = [[InterfaceViewController alloc] init];
    nav.VCdelegate = self;
    [nav showCameraWithParentController:self];
}


#pragma mark - 返回image
- (void)didTakePicture:(InterfaceViewController *)navigationController image:(UIImage *)image {
    SecondViewController *con = [[SecondViewController alloc] init];
    con.postImage = image;
    [navigationController pushViewController:con animated:YES];
//    [navigationController dismissViewControllerAnimated:YES completion:nil];
//    [self.navigationController pushViewController:con animated:YES];
}
@end
