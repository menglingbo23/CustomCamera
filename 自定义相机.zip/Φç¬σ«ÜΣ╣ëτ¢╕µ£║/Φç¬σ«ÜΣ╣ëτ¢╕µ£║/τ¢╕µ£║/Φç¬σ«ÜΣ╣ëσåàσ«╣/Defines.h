//
//  Defines.h
//  自定义相机
//
//  Created by 孟令博 on 16/7/1.
//  Copyright © 2016年 孟令博. All rights reserved.
//

#ifndef Defines_h
#define Defines_h
#define kNotificationOrientationChange          @"kNotificationOrientationChange"

//frame and size
#define SC_DEVICE_BOUNDS    [[UIScreen mainScreen] bounds]
#define SC_DEVICE_SIZE      [[UIScreen mainScreen] bounds].size

#define SC_APP_FRAME        [UIScreen mainScreen].bounds
#define SC_APP_SIZE         [UIScreen mainScreen].bounds.size

#define WEAKSELF_SC __weak __typeof(&*self)weakSelf_SC = self;

#endif /* Defines_h */
