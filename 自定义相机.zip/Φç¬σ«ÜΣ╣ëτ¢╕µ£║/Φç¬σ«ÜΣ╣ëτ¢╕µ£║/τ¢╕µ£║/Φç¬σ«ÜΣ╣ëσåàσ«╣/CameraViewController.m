//
//  CameraViewController.m
//  自定义相机
//
//  Created by 孟令博 on 16/7/1.
//  Copyright © 2016年 孟令博. All rights reserved.
//

#import "CameraViewController.h"
#import "InterfaceViewController.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import "ImageViewController.h"
#import "Defines.h"
#import <Photos/Photos.h>
#define CAMERA_TOPVIEW_HEIGHT   44  //title
#define CAMERA_MENU_VIEW_HEIGH  44  //menu

@interface CameraViewController ()<UIImagePickerControllerDelegate, UINavigationControllerDelegate> {
    ALAssetsLibrary *_assetsLibrary;
    UIButton *_albumBtn;
}

@property (nonatomic, strong) ImageViewController *captureManager;

/** 顶部view */
@property (nonatomic, strong) UIView *topContainerView;
/** 除了顶部标题、拍照区域剩下的所有区域 */
@property (nonatomic, strong) UIView *bottomContainerView;
/** 闪关灯 前后摄像头按钮 */
@property (nonatomic, strong) UIView *cameraMenuView;
/** 相机按钮集合 */
@property (nonatomic, strong) NSMutableSet *cameraBtnSet;

@property (nonatomic, strong) NSMutableArray *assetGroupList;

@end

@implementation CameraViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        _cameraBtnSet = [[NSMutableSet alloc] init];
    }
    return self;
}
- (BOOL)prefersStatusBarHidden
{
    return YES;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];
    
    //navigation bar
    if (self.navigationController && !self.navigationController.navigationBarHidden) {
        self.navigationController.navigationBarHidden = YES;
    }
    if ([self respondsToSelector:@selector(setNeedsStatusBarAppearanceUpdate)]) {
        [self prefersStatusBarHidden];
        [self performSelector:@selector(setNeedsStatusBarAppearanceUpdate)];
    }
    //notification
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kNotificationOrientationChange object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(orientationDidChange:) name:kNotificationOrientationChange object:nil];
    
    _assetsLibrary = [[ALAssetsLibrary alloc] init];
    _assetGroupList = [[NSMutableArray alloc] init];
    [self loadGroupsData];
    
    __weak CameraViewController *weakself = self;
    [[NSNotificationCenter defaultCenter] addObserverForName:ALAssetsLibraryChangedNotification
                                                      object:nil
                                                       queue:[NSOperationQueue mainQueue]
                                                  usingBlock:^(NSNotification *note) {
                                                      NSDictionary *userInfo = note.userInfo;
                                                      if (!userInfo || [[userInfo allKeys] count] > 0) {
                                                          [weakself loadGroupsData];
                                                      }
                                                  }];
    //session manager
    ImageViewController *manager = [[ImageViewController alloc] init];
    
    //AvcaptureManager
    if (CGRectEqualToRect(_previewRect, CGRectZero)) {
        self.previewRect = CGRectMake(0, CAMERA_TOPVIEW_HEIGHT + 100, SC_APP_SIZE.width, 200);
    }
    [manager configureWithParentLayer:self.view previewRect:_previewRect];
    self.captureManager = manager;
    
    [self addTopView];
    [self addbottomContainerView];
    [self addCameraMenuView];
    
    [_captureManager.session startRunning];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    //隐藏状态栏
    if ([self respondsToSelector:@selector(setNeedsStatusBarAppearanceUpdate)]) {
        [self prefersStatusBarHidden];
        [self performSelector:@selector(setNeedsStatusBarAppearanceUpdate)];
    } }

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:UIStatusBarAnimationSlide];
}


- (void)dealloc {
    
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kNotificationOrientationChange object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:ALAssetsLibraryChangedNotification object:nil];
    
    
    self.captureManager = nil;
}

// Load assets groups data from system.
- (void)loadGroupsData {
    [self.assetGroupList removeAllObjects];
    CameraViewController *__weak weakSelf = self;
    
    // Callback block for assets library to return result set with groups.
    ALAssetsLibraryGroupsEnumerationResultsBlock groupResultBlock =
    ^(ALAssetsGroup *group, BOOL *stop) {
        if (group) {
            if (group.numberOfAssets > 0) {
                [weakSelf.assetGroupList addObject:group];
            }
        } else {
            // Reset album button image after group data loaded successfully.
            [weakSelf resetAlbumBtnImage];
        }
    };
    // Error block for asstes library.
    ALAssetsLibraryAccessFailureBlock failureBlock = ^(NSError *error) {
        
    };
    
    // Fetch assets groups from system's asstes library.
    [_assetsLibrary enumerateGroupsWithTypes:ALAssetsGroupAll
                                  usingBlock:groupResultBlock
                                failureBlock:failureBlock];
}

- (void)resetAlbumBtnImage {
    ALAssetsGroup *group = [_assetGroupList firstObject];
    CGImageRef imageRef = [group posterImage];
    UIImage *image = [[UIImage alloc] initWithCGImage:imageRef];
    if (image) {
        [_albumBtn setImage:image forState:UIControlStateNormal];
    }
}
#pragma mark -------------UI---------------
//顶部菜单
- (void)addTopView {
    if (!_topContainerView) {
        CGRect topFrame = CGRectMake(0, 0, SC_APP_SIZE.width, CAMERA_TOPVIEW_HEIGHT + 100);
        
        UIView *tView = [[UIView alloc] initWithFrame:topFrame];
        tView.backgroundColor = [UIColor clearColor];
        [self.view addSubview:tView];
        self.topContainerView = tView;
        
        UIView *emptyView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, topFrame.size.width, topFrame.size.height)];
        emptyView.backgroundColor = [UIColor blackColor];
        emptyView.alpha = 1.0f;
        [_topContainerView addSubview:emptyView];
    }
    [self addMenuViewButtons];
}

//bottomContainerView，总体
- (void)addbottomContainerView {
    
    CGFloat bottomY = _captureManager.previewLayer.frame.origin.y + _captureManager.previewLayer.frame.size.height;
    CGRect bottomFrame = CGRectMake(0, bottomY, SC_APP_SIZE.width, SC_APP_SIZE.height - bottomY);
    
    UIView *view = [[UIView alloc] initWithFrame:bottomFrame];
    view.backgroundColor = [UIColor clearColor];
    [self.view addSubview:view];
    self.bottomContainerView = view;
}

//拍照菜单栏
- (void)addCameraMenuView {
    
    //拍照按钮
    CGFloat cameraBtnLength = 80;
    [self buildButton:CGRectMake((SC_APP_SIZE.width - cameraBtnLength) / 2, (_bottomContainerView.frame.size.height - cameraBtnLength)/2 , cameraBtnLength, cameraBtnLength)
         normalImgStr:@"shot.png"
      highlightImgStr:@"shot_h.png"
       selectedImgStr:@""
               action:@selector(takePictureBtnPressed:)
           parentView:_bottomContainerView];
}

- (void)showAlbum {
    InterfaceViewController *nav = (InterfaceViewController*)self.navigationController;
    if ([nav.VCdelegate respondsToSelector:@selector(showAlbum:)]) {
        [nav.VCdelegate showAlbum:nav];
    }
}
//菜单栏上的按钮
- (void)addMenuViewButtons {
    NSMutableArray *normalArr = [[NSMutableArray alloc] initWithObjects:@"photo_close_icon", @"flashing_off",@"switch_camera",  nil];
    NSMutableArray *highlightArr = [[NSMutableArray alloc] initWithObjects:@"", @"", @"", nil];
    NSMutableArray *selectedArr = [[NSMutableArray alloc] initWithObjects:@"", @"", @"", nil];
    
    NSMutableArray *actionArr = [[NSMutableArray alloc] initWithObjects:@"dismissBtnPressed:",  @"flashBtnPressed:", @"switchCameraBtnPressed:", nil];
    
    CGFloat eachW = CAMERA_MENU_VIEW_HEIGH;
    CGFloat theH = CAMERA_MENU_VIEW_HEIGH;
    UIView *parent = _topContainerView;
    for (int i = 0; i < actionArr.count; i++) {
        UIButton * btn = [self buildButton:CGRectMake(eachW * i, CAMERA_TOPVIEW_HEIGHT - theH, eachW, theH)
                              normalImgStr:[normalArr objectAtIndex:i]
                           highlightImgStr:[highlightArr objectAtIndex:i]
                            selectedImgStr:[selectedArr objectAtIndex:i]
                                    action:NSSelectorFromString([actionArr objectAtIndex:i])
                                parentView:parent];
        btn.tag = i + 1;
        [_cameraBtnSet addObject:btn];
    }
    CGRect switchCameraframe = [_topContainerView viewWithTag:3].frame;
    switchCameraframe.origin.x = SC_APP_SIZE.width - switchCameraframe.size.width - 10;
    [_topContainerView viewWithTag:3].frame = switchCameraframe;
    
    CGRect flashFrame = [_topContainerView viewWithTag:2].frame;
    flashFrame.origin.x = (parent.frame.size.width - flashFrame.size.width) / 2;
    [_topContainerView viewWithTag:2].frame = flashFrame;
}

- (UIButton*)buildButton:(CGRect)frame
            normalImgStr:(NSString*)normalImgStr
         highlightImgStr:(NSString*)highlightImgStr
          selectedImgStr:(NSString*)selectedImgStr
                  action:(SEL)action
              parentView:(UIView*)parentView {
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = frame;
    if (normalImgStr.length > 0) {
        [btn setImage:[UIImage imageNamed:normalImgStr] forState:UIControlStateNormal];
    }
    if (highlightImgStr.length > 0) {
        [btn setImage:[UIImage imageNamed:highlightImgStr] forState:UIControlStateHighlighted];
    }
    if (selectedImgStr.length > 0) {
        [btn setImage:[UIImage imageNamed:selectedImgStr] forState:UIControlStateSelected];
    }
    [btn addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    [parentView addSubview:btn];
    
    return btn;
}

#pragma mark -------------button actions---------------
//拍照页面，拍照按钮
- (void)takePictureBtnPressed:(UIButton*)sender {
    
    
    sender.userInteractionEnabled = YES;
    
    __block UIActivityIndicatorView *actiView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    actiView.center = CGPointMake(self.view.center.x, self.view.center.y - CAMERA_TOPVIEW_HEIGHT);
    [actiView startAnimating];
    [self.view addSubview:actiView];
    
    WEAKSELF_SC
    [_captureManager takePicture:^(UIImage *stillImage) {
        
        [actiView stopAnimating];
        [actiView removeFromSuperview];
        actiView = nil;
        
        //your code 0
        InterfaceViewController *nav = (InterfaceViewController*)weakSelf_SC.navigationController;
        if ([nav.VCdelegate respondsToSelector:@selector(didTakePicture:image:)]) {
            [nav.VCdelegate didTakePicture:nav image:stillImage];
        }
    }];
}

- (void)tmpBtnPressed:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

//拍照页面，"X"按钮
- (void)dismissBtnPressed:(id)sender {
    if (self.navigationController) {
        if (self.navigationController.viewControllers.count == 1) {
            [self.navigationController dismissViewControllerAnimated:YES completion:nil];
        } else {
            [self.navigationController popViewControllerAnimated:YES];
        }
    } else {
        [self.navigationController dismissViewControllerAnimated:YES completion:nil];
    }
}

//拍照页面，切换前后摄像头按钮按钮
- (void)switchCameraBtnPressed:(UIButton*)sender {
    sender.selected = !sender.selected;
    [_captureManager switchCamera:sender.selected];
}

//拍照页面，闪光灯按钮
- (void)flashBtnPressed:(UIButton*)sender {
    [_captureManager switchFlashMode:sender];
}

#pragma mark ------------notification-------------
- (void)orientationDidChange:(NSNotification*)noti {
    
    if (!_cameraBtnSet || _cameraBtnSet.count <= 0) {
        return;
    }
    [_cameraBtnSet enumerateObjectsUsingBlock:^(id obj, BOOL *stop) {
        UIButton *btn = ([obj isKindOfClass:[UIButton class]] ? (UIButton*)obj : nil);
        if (!btn) {
            *stop = YES;
            return ;
        }
        
        btn.layer.anchorPoint = CGPointMake(0.5, 0.5);
        CGAffineTransform transform = CGAffineTransformMakeRotation(0);
        switch ([UIDevice currentDevice].orientation) {
            case UIDeviceOrientationPortrait://1
            {
                transform = CGAffineTransformMakeRotation(0);
                break;
            }
            case UIDeviceOrientationPortraitUpsideDown://2
            {
                transform = CGAffineTransformMakeRotation(M_PI);
                break;
            }
            case UIDeviceOrientationLandscapeLeft://3
            {
                transform = CGAffineTransformMakeRotation(M_PI_2);
                break;
            }
            case UIDeviceOrientationLandscapeRight://4
            {
                transform = CGAffineTransformMakeRotation(-M_PI_2);
                break;
            }
            default:
                break;
        }
        [UIView animateWithDuration:0.3f animations:^{
            btn.transform = transform;
        }];
    }];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    [picker dismissViewControllerAnimated:YES completion:nil];
    InterfaceViewController *nav = (InterfaceViewController*)self.navigationController;
    if ([nav.VCdelegate respondsToSelector:@selector(didTakePicture:image:)]) {
        [nav.VCdelegate didTakePicture:nav image:[info objectForKey:UIImagePickerControllerEditedImage]];
    }
}


@end
