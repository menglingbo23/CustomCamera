//
//  InterfaceViewController.h
//  自定义相机
//
//  Created by 孟令博 on 16/7/1.
//  Copyright © 2016年 孟令博. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol InterfaceVCDelegate;

@interface InterfaceViewController : UINavigationController
//跳转方法
- (void)showCameraWithParentController:(UIViewController*)parentController;

@property (nonatomic, assign) id <InterfaceVCDelegate> VCdelegate;

@end

@protocol InterfaceVCDelegate <NSObject>

@optional
- (BOOL)willDismissNavigationController:(InterfaceViewController *)navigatonController;

- (void)didTakePicture:(InterfaceViewController *)navigationController image:(UIImage*)image;

- (void)showAlbum:(InterfaceViewController *)navigationController;
@end