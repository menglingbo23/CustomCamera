//
//  InterfaceViewController.m
//  自定义相机
//
//  Created by 孟令博 on 16/7/1.
//  Copyright © 2016年 孟令博. All rights reserved.
//

#import "InterfaceViewController.h"
#import "Defines.h"
#import "CameraViewController.h"

@interface InterfaceViewController ()

@end

@implementation InterfaceViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationBarHidden = YES;
    self.hidesBottomBarWhenPushed = YES;
}

#pragma mark - pop
- (void)dismissModalViewControllerAnimated:(BOOL)animated {
    BOOL shouldToDismiss = YES;
    if ([self.VCdelegate respondsToSelector:@selector(willDismissNavigationController:)]) {
        shouldToDismiss = [self.VCdelegate willDismissNavigationController:self];
    }
    if (shouldToDismiss) {
        [super dismissModalViewControllerAnimated:animated];
    }
}

#pragma mark - action(s)
- (void)showCameraWithParentController:(UIViewController*)parentController {
    CameraViewController *con = [[CameraViewController alloc] init];
    [self setViewControllers:[NSArray arrayWithObjects:con, nil]];
    [parentController presentViewController:self animated:YES completion:nil];
}

@end
