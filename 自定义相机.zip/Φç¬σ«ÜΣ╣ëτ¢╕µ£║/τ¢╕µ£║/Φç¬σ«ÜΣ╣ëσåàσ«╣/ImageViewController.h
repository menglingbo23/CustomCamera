//
//  ImageViewController.h
//  自定义相机
//
//  Created by 孟令博 on 16/7/1.
//  Copyright © 2016年 孟令博. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import "Defines.h"

typedef void(^DidCapturePhotoBlock)(UIImage *stillImage);

@interface ImageViewController : UIViewController

/** 创建一个队列防止主线程阻塞 */
@property (nonatomic) dispatch_queue_t sessionQueue;
@property (nonatomic, strong) AVCaptureSession *session;
@property (nonatomic, strong) AVCaptureVideoPreviewLayer *previewLayer;
@property (nonatomic, strong) AVCaptureDeviceInput *inputDevice;
@property (nonatomic, strong) AVCaptureStillImageOutput *stillImageOutput;
//pinch
@property (nonatomic, assign) CGFloat scaleNum;


/** 加载 */
- (void)configureWithParentLayer:(UIView*)parent previewRect:(CGRect)preivewRect;
/** 返回拍照后的照片 */
- (void)takePicture:(DidCapturePhotoBlock)block;
/** 前后摄像头切换 */
- (void)switchCamera:(BOOL)isFrontCamera;
/** 闪光灯 */
- (void)switchFlashMode:(UIButton*)sender;

@end
