//
//  CameraViewController.h
//  自定义相机
//
//  Created by 孟令博 on 16/7/1.
//  Copyright © 2016年 孟令博. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ImageViewController.h"

@interface CameraViewController : UIViewController

@property (nonatomic, assign) CGRect previewRect;
@end
